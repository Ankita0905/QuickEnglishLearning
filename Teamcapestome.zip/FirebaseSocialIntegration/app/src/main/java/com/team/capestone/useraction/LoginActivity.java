package com.team.capestone.useraction;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.Nullable;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.SignInButton;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.Task;
import com.team.capestone.Callback;
import com.team.capestone.MainActivity;
import com.team.capestone.R;
import com.team.capestone.base.BaseActivity;
import com.team.capestone.others.Util;

public class LoginActivity extends BaseActivity {
    private Button btnLogin;
    private EditText etEmail, etPassword;
    private com.team.capestone.useraction.LoginHelper helper;
    private GoogleSignInClient mGoogleSignInClient;

    private final  int RC_SIGN_IN = 1001;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        helper = new com.team.capestone.useraction.LoginHelper();
        btnLogin = findViewById(R.id.btnLogin);
        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        btnLogin.setOnClickListener(v -> {

            if (helper.isValid(etEmail, etPassword)){

                helper.loginWithEmailPassword(etEmail, etPassword, new Callback() {
                    @Override
                    public void onSuccess(Object o) {
                        goToMainUI();
                    }
                });
            }

        });

        findViewById(R.id.tvForgetPassword).setOnClickListener(v -> {
            startActivity(new Intent(LoginActivity.this, com.team.capestone.useraction.ForgetPassword.class));
        });

        findViewById(R.id.tvSignup).setOnClickListener(v -> {
            startActivity(new Intent(LoginActivity.this, com.team.capestone.useraction.SignupActivity.class));
        });

        SignInButton signInButton = findViewById(R.id.sign_in_button);
        signInButton.setSize(SignInButton.SIZE_STANDARD);
        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken("1016242051916-s31vap11pvrgn6vk0mr9ftuq372n3r2o.apps.googleusercontent.com")
                .requestEmail()
                .build();
        mGoogleSignInClient = GoogleSignIn.getClient(this, gso);
        signInButton.findViewById(R.id.sign_in_button).setOnClickListener(v -> {
            signIn();
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        try {
            if (mGoogleSignInClient != null) {
                mGoogleSignInClient.signOut();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void goToMainUI(){
        startActivity(new Intent(LoginActivity.this, MainActivity.class));
        LoginActivity.this.finish();
    }

    private void signIn() {
        Intent signInIntent = mGoogleSignInClient.getSignInIntent();
        startActivityForResult(signInIntent, RC_SIGN_IN);
    }
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == RC_SIGN_IN) {
            Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
            try {
                GoogleSignInAccount account = task.getResult(ApiException.class);
                helper.firebaseAuthWithGoogle(account, new Callback() {
                    @Override
                    public void onSuccess(Object o) {
                        goToMainUI();
                    }
                });
            } catch (ApiException e) {
                Util.showError(e);
            }
        }
    }

}
