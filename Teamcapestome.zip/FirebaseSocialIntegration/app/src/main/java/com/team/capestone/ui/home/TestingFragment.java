package com.team.capestone.ui.home;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.team.capestone.R;
import com.team.capestone.base.BaseFragment;

public class TestingFragment extends BaseFragment {

    private static TestingFragment instance;
    public static TestingFragment newInstance() {

        if (instance == null) {
            Bundle args = new Bundle();

            instance= new TestingFragment();
            instance.setArguments(args);
        }
        return instance;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_testing, container, false);
        return  view;

    }
}
