package com.team.capestone.base;

import androidx.fragment.app.Fragment;

public class BaseFragment extends Fragment {
}
